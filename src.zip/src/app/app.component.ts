import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']  
})
export class AppComponent {
  title = 'Campus Connect';
  // declared array of months.
  months = ["January", "Feburary", "March", "April", "May", 
           "June", "July", "August", "September",
           "October", "November", "December"];
          }
