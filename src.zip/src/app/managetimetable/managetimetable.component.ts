import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-managetimetable',
  templateUrl: './managetimetable.component.html',
  styleUrls: ['./managetimetable.component.css']
})
export class ManagetimetableComponent implements OnInit {

  yearSelected: any;
  branchSelected: any;
  curriculumSelected: any; 
  
  constructor() { }

  ngOnInit() {
    this .yearSelected = this .year[0];
    this .branchSelected = this .branch[0];
  }

  year = ["First","Second","Third"];
  branch = ["BSC-IT","BIM","BAF"];

  curriculumDisplay(){
  this. curriculumSelected = (this .yearSelected + " " + this .branchSelected);

//   switch(this .curriculumSelected) { 
//     case "BSC-IT First": {
//       this.curriculumPath = "src\BIM-Sem-III-and-IV-2017-2018.pdf"; break; }
//     case "BIM First": {this.curriculumPath = "src\BIM-Sem-III-and-IV-2017-2018.pdf"; break; }
//  } 
  }
}
