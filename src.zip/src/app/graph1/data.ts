export var single = [
    { "name": "Nikhil", "value": 10 },
    { "name": "Kunal", "value": 12  },
    { "name": "Amit", "value": 8 },
    { "name": "Chetan", "value": 13 },
    { "name": "Swapnil", "value": 20 },
    { "name": "Rajesh", "value": 6 },
    { "name": "Sulekha", "value": 4 },
    { "name": "Pratik", "value": 10 },
    { "name": "Sunny", "value": 8 },
    { "name": "Prasad", "value": 0 },
    { "name": "Akshar", "value": 20 },
    { "name": "Varsha", "value": 6 },
    { "name": "Sunanda", "value": 4 },
    { "name": "Raj", "value": 10 },
    { "name": "Komal", "value": 8 },
    { "name": "Mayur", "value": 0 }
  ];