import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { single } from './data';
import {NgSelectModule, NgOption} from '@ng-select/ng-select';
import {FormControl, FormGroup, ReactiveFormsModule, FormsModule} from '@angular/forms';

@Component({
  selector: 'app-graph1',
  templateUrl: './graph1.component.html',
  encapsulation: ViewEncapsulation.None,
  styleUrls: ['./graph1.component.css']
})
export class Graph1Component implements OnInit {

  single: any[];
  ChartName: String;
  semSelected: any;
  branchSelected: any;
  graphSelect: any;
  

  branch = ["BSC-IT","BIM","BAF"];
  sem = ["Select Semester","First","Second","Third","Fourth","Fifth","Sixth"];
  graph = ["Syllabus","Attendence"];


  view: any[] = [1000, 400]; //Width and Height of Graph

  // options
  // showText = 'Attendaence bar graph';
  showXAxis = true;
  showYAxis = true;
  gradient = false;
  // showLegend = true;
  showXAxisLabel = true;
  xAxisLabel = 'Student';
  showYAxisLabel = true;
  yAxisLabel = 'Attendence';

  colorScheme = {
    domain: ['#5AA454', '#A10A28', '#C7B42C', '#AAAAAA']
  };


  constructor() {
    Object.assign(this, { single })
   }

  ngOnInit() {
    this .ChartName= 'Attendence details';
  }

  onSelect(event) {
    console.log(event);
  }

}









