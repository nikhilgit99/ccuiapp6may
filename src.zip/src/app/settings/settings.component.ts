import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.css']
})
export class SettingsComponent implements OnInit {

    constructor() { }

  ngOnInit() {  }

  model: any = {};

  editForm(){
    
  }

  onSubmit() {
    alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.model))
  }
  
  
  // fname="";
  // lname="";
  // onSubmit(form: any): void{
  //   console.log(form);
  //   this.fname = form.fname;
  //   this.lname = form.lname;
}



  // get phoneForms() {
  //   return this.myForm.get('phones') as FormArray
  // }

  // addPhone() {

  //   const phone = this.fb.group({ 
  //     area: [],
  //     prefix: [],
  //     line: [],
  //   })

  //   this.phoneForms.push(phone);
  // }

  // deletePhone(i) {
  //   this.phoneForms.removeAt(i)
  // }


  //profileForm: FormGroup;
  

  // getErrorMessage() {
  //   return this.email.hasError('required') ? 'You must enter a value' :
  //       this.email.hasError('email') ? 'Not a valid email' :
  //           '';
  // }


  // this. profileForm = this.fb.group({
  //   firstName: ['', Validators.required],
  //   lastName: [''],
  //   address: this.fb.group({
  //     street: [''],
  //     city: [''],
  //     state: [''],
  //     zip: ['']
  //   }),
  // });
