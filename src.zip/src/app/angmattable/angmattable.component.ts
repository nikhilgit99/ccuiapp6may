import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-angmattable',
  templateUrl: './angmattable.component.html',
  styleUrls: ['./angmattable.component.css']
})
export class AngmattableComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }


  
}
