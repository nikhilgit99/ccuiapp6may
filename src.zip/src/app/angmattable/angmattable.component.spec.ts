import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AngmattableComponent } from './angmattable.component';

describe('AngmattableComponent', () => {
  let component: AngmattableComponent;
  let fixture: ComponentFixture<AngmattableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AngmattableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AngmattableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
