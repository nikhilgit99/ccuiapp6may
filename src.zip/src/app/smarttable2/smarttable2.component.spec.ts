import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Smarttable2Component } from './smarttable2.component';

describe('Smarttable2Component', () => {
  let component: Smarttable2Component;
  let fixture: ComponentFixture<Smarttable2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Smarttable2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Smarttable2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
