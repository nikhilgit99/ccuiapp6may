import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mfdatatable',
  templateUrl: './mfdatatable.component.html',
  styleUrls: ['./mfdatatable.component.css']
})
export class MfdatatableComponent implements OnInit {

  data : any;

  constructor() { }

  ngOnInit() {

    // this .data = curriculumdataimport;
  
    this .data = [{'name':'Anil', 'email' : 'anil.singh581@gmail.com', 'age' :'34', 'city':'Noida, UP, India' },
  {'name':'Anil', 'email' :'anil.singh581@gmail.com', 'age' :'1', 'city':'Noida' },
  {'name':'Sunil', 'email' :'anil.singh581@gmail.com', 'age' :'2', 'city':'Noida' },
  {'name':'Alok', 'email' :'anil.singh581@gmail.com', 'age' :'3', 'city':'Noida' },
  {'name':'Tinku', 'email' :'anil.singh581@gmail.com', 'age' :'4', 'city':'Noida' },
  {'name':'XYZ', 'email' :'anil.singh581@gmail.com', 'age' :'8', 'city':'Noida' },
  {'name':'asas', 'email' :'anil.singh581@gmail.com', 'age' :'9', 'city':'Noida' },
  {'name':'erer', 'email' :'anil.singh581@gmail.com', 'age' :'10', 'city':'Noida' },
  {'name':'jhjh', 'email' :'anil.singh581@gmail.com', 'age' :'11', 'city':'Noida' },
  {'name':'asas', 'email' :'anil.singh581@gmail.com', 'age' :'15', 'city':'Noida' },
  {'name':'erer', 'email' :'anil.singh581@gmail.com', 'age' :'20', 'city':'Noida' },
  {'name':'jhjh', 'email' :'anil.singh581@gmail.com', 'age' :'19', 'city':'Noida' }
 ];

}

}
