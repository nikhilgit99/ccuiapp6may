import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MfdatatableComponent } from './mfdatatable.component';

describe('MfdatatableComponent', () => {
  let component: MfdatatableComponent;
  let fixture: ComponentFixture<MfdatatableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MfdatatableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MfdatatableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
