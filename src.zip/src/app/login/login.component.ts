import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpModule } from '@angular/http';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { LoginService } from './login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userName:String='';
  passWord:String='';

  constructor(private router:Router , private loginservice: LoginService){
  }

  //ngOnInit(){}

  ngOnInit(): void {
    this.loginservice.getUsers().subscribe(data => {
      console.log('data : ',data);
    });
}

 validate(){
    console.log("userName : ",this.userName);
    console.log("passWord : ",this.passWord);
    if(this.userName.length>3){
      if(this.userName ===this.passWord){
        console.log("logged in");
        this.router.navigate(['/home'])
      }
    }else{
      console.log("unable to login ");
    }

  }

}