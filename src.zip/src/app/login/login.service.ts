import {Injectable} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

//import { User } from '../models/user.model';




@Injectable()
export class LoginService {

  constructor(private http:HttpClient) {}

  private userUrl = 'http://localhost:8080/user/get';
	//private userUrl = '/api/';

  public getUsers() {
    return this.http.get(this.userUrl);
  }

//   public deleteUser(user) {
//     return this.http.delete(this.userUrl + "/"+ user.id);
//   }

//   public createUser(user) {
//     return this.http.post<User>(this.userUrl, user);
//   }

}