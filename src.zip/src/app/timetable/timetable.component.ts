import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';

@Component({
  selector: 'app-timetable',
  templateUrl: './timetable.component.html',
  styleUrls: ['./timetable.component.css']
})
export class TimetableComponent implements OnInit {

profileForm: FormGroup;
searchBySelection: any;
myProfileBranchSelected: any;
myprofilesemesterSelected: any;
myprofilesubjectSelected: any;

searchByOptions = ["First Name","Subject","Branch"];
myprofilebranch= ["BSC-IT","BIM","BAF","BMS","B.COM"];
myprofilesemester= ["First","Second","Third","Fourth","Fifth","Sixth"];
myprofilesubject= ["Subject1","Subject2","Subject3","Subject4"];


constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.profileForm = this.fb.group({
      firstname: ['Nikhil', Validators.required],
      lastname:  ['Shinde',[Validators.required]],
      email: ['nikhilatdalmia@gmail.com', [Validators.required,Validators.email]],
      mobileno: ['9870745991', [Validators.required,Validators.minLength(10)]],
      qualifications: ['BE - EXTC',[Validators.required]],
      gender: [''],
      address: this.fb.group({
        street: ['M G Road Goregaon west', Validators.required],
        city: ['Mumbai', Validators.required],
        state: ['Maharastra', Validators.required],
        zipcode: ['400062', Validators.required]
      }),
      phones: this.fb.array([])
    })
    this.profileForm.get('firstname').disable();
    this.profileForm.get('lastname').disable();
    this.profileForm.get('email').disable();
    this.profileForm.get('mobileno').disable();
    this.profileForm.get('qualifications').disable();
    //this.profileForm.address.get('street').disable();
  }

// convenience getter for easy access to form fields
get f() { return this.profileForm.controls; }

onSubmit() {
  alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.profileForm.value))
}

onEdit(){
console.log("I m try to Edit");  
this.profileForm.get('firstname').enable();
this.profileForm.get('lastname').enable();
this.profileForm.get('email').enable();
this.profileForm.get('mobileno').enable();
this.profileForm.get('qualifications').enable();
}
  
get phoneForms() {
  return this.profileForm.get('phones') as FormArray
}

addPhone() {
  const phone = this.fb.group({ 
    area: [],
    prefix: [],
    line: [],
  })

  this.phoneForms.push(phone);
}

deletePhone(i) {
  this.phoneForms.removeAt(i)
}
  
}


  // profileForm = new FormGroup({
  //   firstname: new FormControl(''),
  //   lastname: new FormControl(''),
  //   address: new FormGroup({
  //     street: new FormControl(''),
  //     city: new FormControl(''),
  //     state: new FormControl(''),
  //     zipcode: new FormControl(''),
  //   })
  // });

    // https://loiane.com/2017/08/angular-reactive-forms-trigger-validation-on-submit/