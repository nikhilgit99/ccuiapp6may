import {Component, OnInit, ViewChild} from '@angular/core';
import {MatPaginator,MatSort, MatTableDataSource} from '@angular/material';

  @Component({
  selector: 'app-managelibrary',
  templateUrl: './managelibrary.component.html',
  styleUrls: ['./managelibrary.component.css']
})
export class ManagelibraryComponent implements OnInit {

  displayedColumns: string[] = ['SrNo', 'bookname', 'author','publications','available','racknumber','subject','semester','branch'];
  semSelected: any;
  branchSelected: any;
  subjectSelected: any;

  branch = ["Select Branch","BSC-IT","BIM","BAF"];
  sem = ["Select Semester","First","Second","Third","Fourth","Fifth","Sixth"];
  subject = ["Select Subject","Introduction to Information theory and applications","Mathematics I","Introduction to Digital electronics",
            "Digital Computer Fundamentals","Introduction to Programming","Mathematics II","Design and analysis of algorithms",
            "Electronics and Tele Communication Systems","Professional Skill Development course","Computer Graphics",
            "Computational Mathematics","Systems Programming","Object oriented Programming","Computer Networks",
            "Logic, Discrete Mathematical Structures","Data base concepts and Systems","Operating Systems"];

  dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);

  public show_listview : boolean = true;
  public show_detailview : boolean = false;

  // @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  ngOnInit() {
    this.dataSource.sort = this.sort;
    // this.dataSource.paginator = this.paginator;
    this .semSelected = this .sem[0];
    this .branchSelected = this .branch[0];
    this .subjectSelected = this .subject[0];
  }

  Listelementclicked(Element){
    
    this.show_listview = !this.show_listview;  
    console.warn("Element clicked on list page");
    
    this.show_detailview = !this.show_detailview;

  }

}

export interface PeriodicElement {
  SrNo: number;
    bookname: string;
    author: string;
    publications: string;
    available: string;
    racknumber:any;
    subject:any;
    semester:any;
    branch:any;
}

const ELEMENT_DATA: PeriodicElement[] = [
  { SrNo: 1, bookname: 'Maths1', author: 'Kumbhojkar', publications: 'Nirali', available: '10', racknumber: 'A23', subject: 'Introduction to Information theory and applications',
  semester: 'third' , branch: 'BSC-IT' },
{ SrNo: 2, bookname: 'Introduction to Digital electronics', author: 'Kumbhojkar', publications: 'Digital Computer Fundamentals', available: '9', racknumber: 'A23', subject: 'Maths - 1',
semester: 'third' , branch: 'BSC-IT' },
{ SrNo: 3, bookname: 'Maths1', author: 'Integrated system of Kumbhojkar', publications: 'Nirali', available: '8', racknumber: 'A23', subject: 'Maths - 1',
  semester: 'third' , branch: 'BSC-IT' },
{ SrNo: 4, bookname: 'Maths1', author: 'Kumbhojkar', publications: 'Nirali', available: '7', racknumber: 'A23', subject: 'Maths - 1',
semester: 'third' , branch: 'BSC-IT' },
{ SrNo: 5, bookname: 'Maths1', author: 'Kumbhojkar', publications: 'Nirali', available: '10', racknumber: 'A23', subject: 'Maths - 1',
semester: 'third' , branch: 'BSC-IT' },
{ SrNo: 6, bookname: 'Data base concepts and Systems', author: 'Kumbhojkar', publications: 'Nirali', available: '9', racknumber: 'A23', subject: 'Professional Skill Development course',
semester: 'third' , branch: 'BSC-IT' },
{ SrNo: 7, bookname: 'Maths1', author: 'Kumbhojkar', publications: 'Professional Skill Development course', available: '8', racknumber: 'A23', subject: 'Maths - 1',
semester: 'third' , branch: 'BSC-IT' },
{ SrNo: 8, bookname: 'Maths1', author: 'Kumbhojkar', publications: 'Nirali', available: '7', racknumber: 'A23', subject: 'Data base concepts and Systems',
semester: 'third' , branch: 'BSC-IT' },
{ SrNo: 9, bookname: 'Maths1', author: ' Discrete Mathematical Structures', publications: 'Nirali', available: '10', racknumber: 'A23', subject: 'Maths - 1',
  semester: 'third' , branch: 'BSC-IT' },
{ SrNo: 10, bookname: 'Maths1', author: 'Kumbhojkar', publications: 'Nirali', available: '9', racknumber: 'A23', subject: 'Maths - 1',
semester: 'third' , branch: 'BSC-IT' },
{ SrNo: 11, bookname: 'Professional Skill Development course', author: 'Kumbhojkar', publications: 'Nirali', available: '8', racknumber: 'A23', subject: 'Maths - 1',
  semester: 'third' , branch: 'BSC-IT' },
{ SrNo: 12, bookname: 'Maths1', author: 'Kumbhojkar', publications: 'Nirali', available: '7', racknumber: 'A23', subject: ' Discrete Mathematical Structures',
semester: 'third' , branch: 'BSC-IT' }];