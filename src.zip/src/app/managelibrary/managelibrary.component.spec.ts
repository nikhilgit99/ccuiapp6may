import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagelibraryComponent } from './managelibrary.component';

describe('ManagelibraryComponent', () => {
  let component: ManagelibraryComponent;
  let fixture: ComponentFixture<ManagelibraryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManagelibraryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagelibraryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
