import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-library',
  templateUrl: './library.component.html',
  styleUrls: ['./library.component.css']
})
export class LibraryComponent implements OnInit {

  public show_dialog : boolean = false;
  private issuebookshowdetails : boolean = false;
  public button_name : any = 'Show Login Form!';
  model: any = {};
  semSelected: any;
  branchSelected: any;
  branch1Selected;
  studentSelect: any;
  data : any

  branch = ["Select Branch","BSC-IT","BIM","BAF"];
  sem1 = ["Select Branch","BIM","BAF","BSC-IT"];
  sem = ["Select Semester","First","Second","Third","Fourth","Fifth","Sixth"];
  student = ["Select Name","Amit","Kunal","Vishal","Nikhil","Pratik"];

  onSubmit() {
    alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.model))
  }

  constructor() { }

  ngOnInit() {
  
    this .data = [{'name':'Anil', 'email' : 'anil.singh581@gmail.com', 'age' :'34', 'city':'Noida, UP, India' },
  {'name':'Anil', 'email' :'anil.singh581@gmail.com', 'age' :'34', 'city':'Noida' },
  {'name':'Sunil', 'email' :'anil.singh581@gmail.com', 'age' :'34', 'city':'Noida' },
  {'name':'Alok', 'email' :'anil.singh581@gmail.com', 'age' :'34', 'city':'Noida' },
  {'name':'Tinku', 'email' :'anil.singh581@gmail.com', 'age' :'34', 'city':'Noida' },
  {'name':'XYZ', 'email' :'anil.singh581@gmail.com', 'age' :'34', 'city':'Noida' },
  {'name':'asas', 'email' :'anil.singh581@gmail.com', 'age' :'34', 'city':'Noida' },
  {'name':'erer', 'email' :'anil.singh581@gmail.com', 'age' :'34', 'city':'Noida' },
  {'name':'jhjh', 'email' :'anil.singh581@gmail.com', 'age' :'34', 'city':'Noida' }
 ]

  }

  issuebookshow(){
    this.issuebookshowdetails = !this.issuebookshowdetails;
  }

  issuedbook(){
    this.issuebookshowdetails = !this.issuebookshowdetails;
  }

//   $(document).ready(function() {
//     $('#example').DataTable();
// } );

  toggle() {
    this.show_dialog = !this.show_dialog;

    // CHANGE THE TEXT OF THE BUTTON.
    if(this.show_dialog) 
      this.button_name = "Hide Login Form!";
    else
      this.button_name = "Show Login Form!";
  }

  

}


// SrNo: 2, bookname: 'Introduction to Digital electronics', 
// author: 'Kumbhojkar', publications: 'Digital Computer Fundamentals',
//  available: '9', subject: 'Maths - 1',
// semester: 'third' , branch: 'BSC-IT' },

