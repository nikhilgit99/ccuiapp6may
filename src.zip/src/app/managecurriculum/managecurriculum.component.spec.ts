import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagecurriculumComponent } from './managecurriculum.component';

describe('ManagecurriculumComponent', () => {
  let component: ManagecurriculumComponent;
  let fixture: ComponentFixture<ManagecurriculumComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManagecurriculumComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagecurriculumComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
