import { Component, OnInit ,ViewEncapsulation} from '@angular/core';
import {curriculumdataimport} from './curridata';

@Component({
  selector: 'app-managecurriculum',
  templateUrl: './managecurriculum.component.html',
  encapsulation: ViewEncapsulation.None,
  styleUrls: ['./managecurriculum.component.css']
})
export class ManagecurriculumComponent implements OnInit {

  data : any;
  branchSelected: any;
  semSelected: any;
  subjectSelected: any;
  public searchText : string;

  
  branch = ["BSC-IT","BIM","BAF"];
  sem = ["First","Second","Third","Fourth","Fifth","Sixth"];
  subject = ["Introduction to Information theory and applications","Mathematics I","Introduction to Digital electronics",
            "Digital Computer Fundamentals","Introduction to Programming","Mathematics II","Design and analysis of algorithms",
            "Electronics and Tele Communication Systems","Professional Skill Development course","Computer Graphics",
            "Computational Mathematics","Systems Programming","Object oriented Programming","Computer Networks",
            "Logic, Discrete Mathematical Structures","Data base concepts and Systems","Operating Systems"];

  constructor() { }

  ngOnInit() {

    this .data = curriculumdataimport;
  
//     this .data = [{'name':'Anil', 'email' : 'anil.singh581@gmail.com', 'age' :'34', 'city':'Noida, UP, India' },
//   {'name':'Anil', 'email' :'anil.singh581@gmail.com', 'age' :'34', 'city':'Noida' },
//   {'name':'Sunil', 'email' :'anil.singh581@gmail.com', 'age' :'34', 'city':'Noida' },
//   {'name':'Alok', 'email' :'anil.singh581@gmail.com', 'age' :'34', 'city':'Noida' },
//   {'name':'Tinku', 'email' :'anil.singh581@gmail.com', 'age' :'34', 'city':'Noida' },
//   {'name':'XYZ', 'email' :'anil.singh581@gmail.com', 'age' :'34', 'city':'Noida' },
//   {'name':'asas', 'email' :'anil.singh581@gmail.com', 'age' :'34', 'city':'Noida' },
//   {'name':'erer', 'email' :'anil.singh581@gmail.com', 'age' :'34', 'city':'Noida' },
//   {'name':'jhjh', 'email' :'anil.singh581@gmail.com', 'age' :'34', 'city':'Noida' }
//  ];

}
}