import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule} from '@angular/router';
import { FormsModule} from '@angular/forms';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { ReactiveFormsModule} from '@angular/forms';

import { HttpModule } from '@angular/http';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import {LoginService} from './login/login.service';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { NestComponent } from './nest/nest.component';
import { Chart } from 'chart.js';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { TimetableComponent } from './timetable/timetable.component';
import { CurriculumComponent, SafePipe } from './curriculum/curriculum.component';
import { LibraryComponent } from './library/library.component';
import { ProfileComponent } from './profile/profile.component';
import { SmarttableComponent } from './smarttable/smarttable.component';
import { MatFormFieldModule, MatSortModule, MatTableModule, MatPaginatorModule, MatInputModule, MatCheckboxModule, MatMenuModule, MatButtonModule, MatSelectModule, MatChipsModule, } from '@angular/material';
import { Smarttable2Component } from './smarttable2/smarttable2.component';
import { SettingsComponent } from './settings/settings.component';
import { AngMatComponent } from './ang-mat/ang-mat.component';
import { MaterialModule } from './material.module';
import { ManagetimetableComponent } from './managetimetable/managetimetable.component';
import { ManagelibraryComponent } from './managelibrary/managelibrary.component';
import {DataTableModule} from "angular-6-datatable";
import { Graph1Component } from './graph1/graph1.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { ManagecurriculumComponent } from './managecurriculum/managecurriculum.component';
import { searchtablepipe } from './managecurriculum/searchtable.pipe';
import { MfdatatableComponent } from './mfdatatable/mfdatatable.component';
import { AngmattableComponent } from './angmattable/angmattable.component';
import { SharepointComponent } from './sharepoint/sharepoint.component';
import { Login2Component } from './login2/login2.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    NestComponent,
    TimetableComponent,
    CurriculumComponent,
    LibraryComponent,
    ProfileComponent,
    SafePipe,
    SmarttableComponent,
    Smarttable2Component,
    SettingsComponent,
    AngMatComponent,
    ManagetimetableComponent,
    ManagelibraryComponent,
    Graph1Component,
    ManagecurriculumComponent,
    searchtablepipe,
    MfdatatableComponent,
    AngmattableComponent,
    SharepointComponent,
    Login2Component
  ],
  imports: [
    BrowserModule,FormsModule,ReactiveFormsModule,NgxChartsModule,
    HttpClientModule,DataTableModule,
    MatFormFieldModule,MatSortModule,MatTableModule,MatPaginatorModule,MatInputModule,MatCheckboxModule,MatMenuModule,
        HttpModule,BrowserAnimationsModule, MatInputModule, MatButtonModule, MatSelectModule,
        MatCheckboxModule, MatChipsModule,MatFormFieldModule,MaterialModule,NgSelectModule,
          RouterModule.forRoot([
       { path: 'home', component: HomeComponent },
      { path: 'timetable', component:TimetableComponent },
      { path: 'managetimetable', component:ManagetimetableComponent},
      { path: 'curriculum', component:CurriculumComponent },
      { path: 'managecurriculum', component:ManagecurriculumComponent},
      { path: 'viewlibrary', component:LibraryComponent },
      { path: 'managelibrary', component:ManagelibraryComponent },
      { path: 'profile', component:ProfileComponent },
      { path: 'settings', component:SettingsComponent }, 
      { path: '', component:Login2Component },
      { path: 'sharepoint', component:SharepointComponent},
      { path: 'angmat', component:AngMatComponent },
      { path: 'mfdata', component:MfdatatableComponent},
      { path: 'angtab1', component:SmarttableComponent},
      {path: 'angtab2' , component:Smarttable2Component},
      {path:'mdbuikit', component:AngmattableComponent}
      
   ])
    
  ],
  providers: [LoginService],
  bootstrap: [AppComponent , LoginComponent]
})
export class AppModule { }


// https://stackblitz.com/angular/kmoqvxlkgxv?file=app%2Ftable-filtering-example.ts

//https://mdbootstrap.com/plugins/jquery/table-editor/

