import { Component, OnInit} from '@angular/core';
import { DomSanitizer } from "@angular/platform-browser";
import {  ViewEncapsulation, ViewChild, ElementRef, PipeTransform, Pipe } from '@angular/core';

@Pipe({ name: 'safe' })
export class SafePipe implements PipeTransform {
  constructor(private sanitizer: DomSanitizer) { }
  transform(url) {
    return this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }
}

@Component({
  selector: 'app-curriculum',
  templateUrl: './curriculum.component.html',
  encapsulation: ViewEncapsulation.None,
  styleUrls: ['./curriculum.component.css']
})
export class CurriculumComponent implements OnInit {

  branchSelected: any;
  semSelected: any;
  subjectSelected: any;
  curriculumSelected: any;
  curriculumPath: String;  
  
  branch = ["BSC-IT","BIM","BAF"];
  sem = ["First","Second","Third","Fourth","Fifth","Sixth"];
  subject = ["Introduction to Information theory and applications","Mathematics I","Introduction to Digital electronics",
            "Digital Computer Fundamentals","Introduction to Programming","Mathematics II","Design and analysis of algorithms",
            "Electronics and Tele Communication Systems","Professional Skill Development course","Computer Graphics",
            "Computational Mathematics","Systems Programming","Object oriented Programming","Computer Networks",
            "Logic, Discrete Mathematical Structures","Data base concepts and Systems","Operating Systems"];


  constructor() { }

  ngOnInit() {
    this .curriculumPath = "src\BIM-Sem-III-and-IV-2017-2018.pdf";
  }

  curriculumDisplay(){
  this. curriculumSelected = (this .branchSelected);

  switch(this .curriculumSelected) { 
    case "BSC-IT First": {
      this.curriculumPath = "src\BIM-Sem-III-and-IV-2017-2018.pdf"; break; }
    case "BIM First": {this.curriculumPath = "src\BIM-Sem-III-and-IV-2017-2018.pdf"; break; }
    
 } 
  }
}
